/* EE422C Project 2 (Mastermind)
 * Spring 2017
 */
package assignment2;

public class GameConfiguration {

    public static final int guessNumber = 4;
    public static final String[] colors = {"Q","W","E","R","T","Y"};
    public static final int pegNumber = 6;
}
