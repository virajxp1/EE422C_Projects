#GameConfiguration test with failure

This tests the solution's ability to utilizes the GameConfiguration class
to parameterize elements of the game.

This also tests handling a failure to successfully complete the game.
